<?php
    require_once 'connect.php';
   
    $sql="UPDATE library SET connect='connect is modified' WHERE name='zhangsan'";
    if(mysqli_query($con, $sql))
    {
        echo "modify success!";
    }
