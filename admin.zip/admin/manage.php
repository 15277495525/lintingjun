<?php
    require_once 'connect.php';
    $sql="SELECT * FROM library";
    $temp=mysqli_query($con, $sql);
    while($row=mysqli_fetch_assoc($temp))
    {
        $data[]=$row;
    }
    foreach($data as $everyData)
    {
?>
        <a href="delete.handle.php?name=<?php echo $everyData['name']?>">delete</a>
<?php 
        echo $everyData['name'].": ".$everyData['price'];
        echo "<br>";
    }
    ?>
    
    